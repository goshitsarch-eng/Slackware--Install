#!/bin/bash
# Gosh Slack Installer - Automated Slackware Installer
# SPDX-License-Identifier: AGPL-3.0-or-later

set -euo pipefail

#=============================================================================
# CONFIGURATION (override via environment or /etc/gosh-slack.conf)
#=============================================================================
[[ -f /etc/gosh-slack.conf ]] && source /etc/gosh-slack.conf

HOSTNAME="${GOSH_HOSTNAME:-slackbox}"
TIMEZONE="${GOSH_TIMEZONE:-US/Pacific}"
ROOT_PASS="${GOSH_ROOT_PASS:-changeme}"
SLACK_SOURCE="${GOSH_SOURCE:-/mnt/cdrom/slackware64}"
AUTO_REBOOT="${GOSH_AUTO_REBOOT:-false}"

#=============================================================================
# LOGGING
#=============================================================================
log() { echo "[GOSH] $*"; }
die() { echo "[GOSH] ERROR: $*" >&2; exit 1; }

#=============================================================================
# BOOT MODE DETECTION
#=============================================================================
detect_boot_mode() {
    if [[ -d /sys/firmware/efi ]]; then
        echo "uefi"
    else
        echo "bios"
    fi
}

BOOT_MODE=$(detect_boot_mode)

#=============================================================================
# AUTO-DETECT TARGET DISK
#=============================================================================
detect_target_disk() {
    local install_disk=""
    
    # Find which disk holds our install source
    if [[ -d "$SLACK_SOURCE" ]]; then
        install_disk=$(df "$SLACK_SOURCE" 2>/dev/null | tail -1 | awk '{print $1}' | sed 's/p\?[0-9]*$//' | xargs basename 2>/dev/null || true)
    fi
    
    # Also exclude the live media by checking what's mounted at /mnt/cdrom or similar
    for mnt in /mnt/cdrom /mnt/source /media/*; do
        if mountpoint -q "$mnt" 2>/dev/null; then
            local mnt_disk=$(df "$mnt" 2>/dev/null | tail -1 | awk '{print $1}' | sed 's/p\?[0-9]*$//' | xargs basename 2>/dev/null || true)
            [[ -n "$mnt_disk" ]] && install_disk="$install_disk $mnt_disk"
        fi
    done
    
    # Find largest non-removable disk, excluding install media
    lsblk -dnbo NAME,SIZE,RM,TYPE | while read name size rm dtype; do
        [[ "$rm" != "0" ]] && continue
        [[ "$dtype" != "disk" ]] && continue
        
        local skip=false
        for excl in $install_disk; do
            [[ "$name" == "$excl" ]] && skip=true
        done
        $skip && continue
        
        echo "$size /dev/$name"
    done | sort -rn | head -1 | awk '{print $2}'
}

#=============================================================================
# PARTITION NAMING HELPER
#=============================================================================
get_partition_path() {
    local disk="$1"
    local num="$2"
    
    if [[ "$disk" =~ nvme[0-9]+n[0-9]+$ ]] || \
       [[ "$disk" =~ mmcblk[0-9]+$ ]] || \
       [[ "$disk" =~ loop[0-9]+$ ]] || \
       [[ "$disk" =~ nbd[0-9]+$ ]]; then
        echo "${disk}p${num}"
    else
        echo "${disk}${num}"
    fi
}

#=============================================================================
# MAIN
#=============================================================================
main() {
    log "=== GOSH SLACK INSTALLER ==="
    
    # Detect target
    TARGET_DISK=$(detect_target_disk)
    [[ -z "$TARGET_DISK" || ! -b "$TARGET_DISK" ]] && die "Could not detect target disk"
    
    # Partition paths
    if [[ "$BOOT_MODE" == "uefi" ]]; then
        PART_EFI=$(get_partition_path "$TARGET_DISK" 1)
        PART_ROOT=$(get_partition_path "$TARGET_DISK" 2)
        PART_SWAP=$(get_partition_path "$TARGET_DISK" 3)
    else
        PART_ROOT=$(get_partition_path "$TARGET_DISK" 1)
        PART_SWAP=$(get_partition_path "$TARGET_DISK" 2)
    fi
    
    TARGET="/mnt/target"
    
    # Sanity checks
    [[ $EUID -ne 0 ]] && die "Run as root"
    [[ ! -d "$SLACK_SOURCE" ]] && die "Source not found: $SLACK_SOURCE"
    
    # Calculate swap
    RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    RAM_GB=$(( (RAM_KB + 1048575) / 1048576 ))
    SWAP_GB=$RAM_GB
    [[ $SWAP_GB -gt 8 ]] && SWAP_GB=8
    [[ $SWAP_GB -lt 1 ]] && SWAP_GB=1
    
    # Disk size check
    DISK_SIZE_GB=$(( $(blockdev --getsize64 "$TARGET_DISK") / 1073741824 ))
    [[ "$BOOT_MODE" == "uefi" ]] && MIN_SIZE=$(( SWAP_GB + 5 )) || MIN_SIZE=$(( SWAP_GB + 4 ))
    [[ $DISK_SIZE_GB -lt $MIN_SIZE ]] && die "Disk too small: ${DISK_SIZE_GB}GB < ${MIN_SIZE}GB required"
    
    # Summary
    log "Boot mode:   $BOOT_MODE"
    log "Target:      $TARGET_DISK (${DISK_SIZE_GB}GB)"
    log "Swap:        ${SWAP_GB}GB"
    log ""
    log "Starting in 5 seconds... (Ctrl+C to abort)"
    sleep 5
    
    # Partition
    log "Partitioning $TARGET_DISK..."
    wipefs -af "$TARGET_DISK"
    
    if [[ "$BOOT_MODE" == "uefi" ]]; then
        parted -s "$TARGET_DISK" mklabel gpt
        parted -s "$TARGET_DISK" mkpart "EFI" fat32 1MiB 513MiB
        parted -s "$TARGET_DISK" set 1 esp on
        parted -s "$TARGET_DISK" mkpart "Linux" ext4 513MiB "-${SWAP_GB}GiB"
        parted -s "$TARGET_DISK" mkpart "Swap" linux-swap "-${SWAP_GB}GiB" 100%
    else
        parted -s "$TARGET_DISK" mklabel msdos
        parted -s "$TARGET_DISK" mkpart primary ext4 1MiB "-${SWAP_GB}GiB"
        parted -s "$TARGET_DISK" set 1 boot on
        parted -s "$TARGET_DISK" mkpart primary linux-swap "-${SWAP_GB}GiB" 100%
    fi
    
    partprobe "$TARGET_DISK"
    sleep 2
    
    # Format
    log "Formatting..."
    [[ "$BOOT_MODE" == "uefi" ]] && mkfs.fat -F32 "$PART_EFI"
    mkfs.ext4 -F "$PART_ROOT"
    mkswap "$PART_SWAP"
    swapon "$PART_SWAP"
    
    # Mount
    log "Mounting target..."
    mkdir -p "$TARGET"
    mount "$PART_ROOT" "$TARGET"
    [[ "$BOOT_MODE" == "uefi" ]] && { mkdir -p "$TARGET/boot/efi"; mount "$PART_EFI" "$TARGET/boot/efi"; }
    
    # Install packages
    log "Installing packages..."
    for series in a ap d e f k kde l n t tcl x xap xfce y; do
        if [[ -d "$SLACK_SOURCE/$series" ]]; then
            log "  Series: $series"
            for pkg in "$SLACK_SOURCE/$series"/*.t?z; do
                installpkg --root "$TARGET" --terse "$pkg"
            done
        fi
    done
    
    # Configure fstab
    log "Configuring system..."
    if [[ "$BOOT_MODE" == "uefi" ]]; then
        cat > "$TARGET/etc/fstab" <<EOF
$PART_ROOT    /            ext4    defaults        1   1
$PART_EFI     /boot/efi    vfat    defaults        0   2
$PART_SWAP    swap         swap    defaults        0   0
devpts        /dev/pts     devpts  gid=5,mode=620  0   0
proc          /proc        proc    defaults        0   0
tmpfs         /dev/shm     tmpfs   nosuid,nodev    0   0
EOF
    else
        cat > "$TARGET/etc/fstab" <<EOF
$PART_ROOT    /         ext4    defaults        1   1
$PART_SWAP    swap      swap    defaults        0   0
devpts        /dev/pts  devpts  gid=5,mode=620  0   0
proc          /proc     proc    defaults        0   0
tmpfs         /dev/shm  tmpfs   nosuid,nodev    0   0
EOF
    fi
    
    # Hostname, timezone, password, network
    echo "$HOSTNAME" > "$TARGET/etc/HOSTNAME"
    echo "127.0.0.1   localhost $HOSTNAME" > "$TARGET/etc/hosts"
    ln -sf "/usr/share/zoneinfo/$TIMEZONE" "$TARGET/etc/localtime"
    echo "root:$ROOT_PASS" | chroot "$TARGET" chpasswd
    
    cat > "$TARGET/etc/rc.d/rc.inet1.conf" <<EOF
IPADDR[0]=""
NETMASK[0]=""
USE_DHCP[0]="yes"
DHCP_HOSTNAME[0]="$HOSTNAME"
EOF
    
    # Bootloader
    mount --bind /dev "$TARGET/dev"
    mount --bind /proc "$TARGET/proc"
    mount --bind /sys "$TARGET/sys"
    
    if [[ "$BOOT_MODE" == "uefi" ]]; then
        log "Installing ELILO..."
        mkdir -p "$TARGET/boot/efi/EFI/Slackware"
        cp "$TARGET/usr/share/elilo"/*.efi "$TARGET/boot/efi/EFI/Slackware/" 2>/dev/null || true
        
        KERNEL=$(ls "$TARGET/boot/vmlinuz-"* 2>/dev/null | head -1 | xargs basename || echo "vmlinuz")
        
        cat > "$TARGET/boot/efi/EFI/Slackware/elilo.conf" <<EOF
timeout = 50
default = Linux
image = $KERNEL
    label = Linux
    root = $PART_ROOT
    read-only
EOF
        cp "$TARGET/boot/$KERNEL" "$TARGET/boot/efi/EFI/Slackware/"
        
        if command -v efibootmgr &>/dev/null; then
            efibootmgr -c -d "$TARGET_DISK" -p 1 -l "\\EFI\\Slackware\\elilo.efi" -L "Slackware" 2>/dev/null || true
        fi
    else
        log "Installing LILO..."
        cat > "$TARGET/etc/lilo.conf" <<EOF
boot = $TARGET_DISK
compact
lba32
vga = normal
read-only
timeout = 50
image = /boot/vmlinuz
    root = $PART_ROOT
    label = Linux
EOF
        chroot "$TARGET" /sbin/lilo
    fi
    
    umount "$TARGET/sys" "$TARGET/proc" "$TARGET/dev"
    
    # Cleanup
    log "Cleaning up..."
    swapoff "$PART_SWAP"
    [[ "$BOOT_MODE" == "uefi" ]] && umount "$TARGET/boot/efi"
    umount "$TARGET"
    
    log "=== INSTALLATION COMPLETE ==="
    log "Remove install media and reboot."
    
    if [[ "$AUTO_REBOOT" == "true" ]]; then
        log "Rebooting in 10 seconds..."
        sleep 10
        reboot -f
    fi
}

main "$@"
