#!/bin/bash
# Build custom Gosh Slack ISO from stock Slackware
# SPDX-License-Identifier: AGPL-3.0-or-later

set -euo pipefail

#=============================================================================
# CONFIGURATION
#=============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"
WORK_DIR="${WORK_DIR:-/tmp/gosh-slack-build}"
OUTPUT_DIR="${OUTPUT_DIR:-$REPO_ROOT/output}"

# Slackware version and mirror
SLACK_VERSION="${SLACK_VERSION:-15.0}"
SLACK_ARCH="${SLACK_ARCH:-64}"
SLACK_MIRROR="${SLACK_MIRROR:-https://mirrors.slackware.com/slackware}"

# Derived
if [[ "$SLACK_ARCH" == "64" ]]; then
    SLACK_NAME="slackware64-${SLACK_VERSION}"
    ISO_NAME="slackware64-${SLACK_VERSION}-install-dvd.iso"
else
    SLACK_NAME="slackware-${SLACK_VERSION}"
    ISO_NAME="slackware-${SLACK_VERSION}-install-dvd.iso"
fi

ISO_URL="${SLACK_MIRROR}/${SLACK_NAME}/iso/${ISO_NAME}"
OUTPUT_ISO="${OUTPUT_DIR}/gosh-slack-${SLACK_VERSION}-${SLACK_ARCH}.iso"

#=============================================================================
# HELPERS
#=============================================================================
log() { echo "[BUILD] $*"; }
die() { echo "[BUILD] ERROR: $*" >&2; exit 1; }

cleanup() {
    log "Cleaning up..."
    [[ -d "$WORK_DIR/iso_mount" ]] && umount "$WORK_DIR/iso_mount" 2>/dev/null || true
    # Don't remove work dir automatically - might want to debug
}
trap cleanup EXIT

check_deps() {
    local missing=()
    for cmd in xorriso curl unsquashfs mksquashfs cpio gzip; do
        command -v "$cmd" &>/dev/null || missing+=("$cmd")
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        die "Missing dependencies: ${missing[*]}"
    fi
}

#=============================================================================
# MAIN BUILD
#=============================================================================
main() {
    check_deps
    
    log "=== GOSH SLACK ISO BUILDER ==="
    log "Slackware: ${SLACK_NAME}"
    log "Work dir:  ${WORK_DIR}"
    log "Output:    ${OUTPUT_ISO}"
    log ""
    
    # Setup directories
    mkdir -p "$WORK_DIR"/{iso_mount,iso_extract,initrd_work}
    mkdir -p "$OUTPUT_DIR"
    
    # Download ISO if not present
    local source_iso="$WORK_DIR/$ISO_NAME"
    if [[ ! -f "$source_iso" ]]; then
        log "Downloading Slackware ISO..."
        curl -L -o "$source_iso" "$ISO_URL" || die "Failed to download ISO"
    else
        log "Using cached ISO: $source_iso"
    fi
    
    # Mount source ISO
    log "Mounting source ISO..."
    mount -o loop,ro "$source_iso" "$WORK_DIR/iso_mount" || die "Failed to mount ISO"
    
    # Extract ISO contents (excluding the large packages initially for speed test)
    log "Extracting ISO contents..."
    rsync -a --info=progress2 "$WORK_DIR/iso_mount/" "$WORK_DIR/iso_extract/"
    
    # Unmount source
    umount "$WORK_DIR/iso_mount"
    
    # Extract initrd
    log "Extracting initrd..."
    local initrd_src="$WORK_DIR/iso_extract/isolinux/initrd.img"
    [[ -f "$initrd_src" ]] || die "initrd.img not found"
    
    cd "$WORK_DIR/initrd_work"
    gzip -dc "$initrd_src" | cpio -idm 2>/dev/null
    
    # Inject our installer script
    log "Injecting gosh-slack-installer..."
    cp "$REPO_ROOT/gosh-slack-installer.sh" "$WORK_DIR/initrd_work/usr/bin/gosh-slack-installer"
    chmod +x "$WORK_DIR/initrd_work/usr/bin/gosh-slack-installer"
    
    # Create config file with defaults
    cat > "$WORK_DIR/initrd_work/etc/gosh-slack.conf" <<'EOF'
# Gosh Slack Installer Configuration
# Edit these values or override via kernel command line

GOSH_HOSTNAME="slackbox"
GOSH_TIMEZONE="US/Pacific"
GOSH_ROOT_PASS="changeme"
GOSH_SOURCE="/mnt/cdrom/slackware64"
GOSH_AUTO_REBOOT="false"
EOF
    
    # Create auto-start script that runs on boot
    cat > "$WORK_DIR/initrd_work/etc/rc.d/rc.gosh" <<'EOF'
#!/bin/bash
# Gosh Slack auto-installer hook

# Check for gosh_auto kernel parameter
if grep -q "gosh_auto" /proc/cmdline; then
    # Parse kernel command line for config overrides
    for param in $(cat /proc/cmdline); do
        case "$param" in
            gosh_hostname=*) export GOSH_HOSTNAME="${param#*=}" ;;
            gosh_timezone=*) export GOSH_TIMEZONE="${param#*=}" ;;
            gosh_pass=*)     export GOSH_ROOT_PASS="${param#*=}" ;;
            gosh_reboot=*)   export GOSH_AUTO_REBOOT="${param#*=}" ;;
        esac
    done
    
    # Wait for devices to settle
    sleep 3
    
    # Mount the CD/DVD
    mkdir -p /mnt/cdrom
    for dev in /dev/sr0 /dev/cdrom /dev/dvd; do
        [[ -b "$dev" ]] && mount -o ro "$dev" /mnt/cdrom 2>/dev/null && break
    done
    
    # Also try USB media
    if [[ ! -d /mnt/cdrom/slackware64 ]]; then
        for dev in /dev/sd?1 /dev/sd?2; do
            [[ -b "$dev" ]] || continue
            mount -o ro "$dev" /mnt/cdrom 2>/dev/null && [[ -d /mnt/cdrom/slackware64 ]] && break
            umount /mnt/cdrom 2>/dev/null || true
        done
    fi
    
    # Run installer
    if [[ -d /mnt/cdrom/slackware64 ]] || [[ -d /mnt/cdrom/slackware ]]; then
        exec /usr/bin/gosh-slack-installer
    else
        echo "[GOSH] Could not find Slackware packages on media"
        echo "[GOSH] Dropping to shell..."
    fi
fi
EOF
    chmod +x "$WORK_DIR/initrd_work/etc/rc.d/rc.gosh"
    
    # Hook into rc.S to call our script
    # Add near the end of rc.S, before it drops to shell
    if [[ -f "$WORK_DIR/initrd_work/etc/rc.d/rc.S" ]]; then
        # Insert our hook before the final shell/setup call
        sed -i '/# Start the main setup/i \
# Gosh Slack auto-installer hook\n\
if [ -x /etc/rc.d/rc.gosh ]; then\n\
  /etc/rc.d/rc.gosh\n\
fi\n' "$WORK_DIR/initrd_work/etc/rc.d/rc.S"
    fi
    
    # Rebuild initrd
    log "Rebuilding initrd..."
    cd "$WORK_DIR/initrd_work"
    find . | cpio -o -H newc 2>/dev/null | gzip -9 > "$WORK_DIR/iso_extract/isolinux/initrd.img"
    
    # Add auto-install boot option to isolinux
    log "Adding boot menu entry..."
    local isolinux_cfg="$WORK_DIR/iso_extract/isolinux/isolinux.cfg"
    
    # Append our boot option
    cat >> "$isolinux_cfg" <<'EOF'

LABEL gosh
  MENU LABEL Gosh Slack ^Auto-Install
  KERNEL huge.s
  APPEND initrd=initrd.img load_ramdisk=1 prompt_ramdisk=0 rw printk.time=0 gosh_auto
  TEXT HELP
  Fully automated Slackware installation.
  WARNING: This will DESTROY all data on the target disk!
  ENDTEXT

LABEL gosh-custom
  MENU LABEL Gosh Slack Auto-Install (^Custom)
  KERNEL huge.s
  APPEND initrd=initrd.img load_ramdisk=1 prompt_ramdisk=0 rw printk.time=0 gosh_auto gosh_reboot=true
  TEXT HELP
  Automated install with auto-reboot after completion.
  ENDTEXT
EOF
    
    # Also add UEFI boot entries if grub.cfg exists
    local grub_cfg="$WORK_DIR/iso_extract/EFI/BOOT/grub.cfg"
    if [[ -f "$grub_cfg" ]]; then
        cat >> "$grub_cfg" <<'EOF'

menuentry "Gosh Slack Auto-Install" {
    linux /kernels/huge.s load_ramdisk=1 prompt_ramdisk=0 rw printk.time=0 gosh_auto
    initrd /isolinux/initrd.img
}

menuentry "Gosh Slack Auto-Install (with reboot)" {
    linux /kernels/huge.s load_ramdisk=1 prompt_ramdisk=0 rw printk.time=0 gosh_auto gosh_reboot=true
    initrd /isolinux/initrd.img
}
EOF
    fi
    
    # Rebuild ISO
    log "Building output ISO..."
    cd "$WORK_DIR/iso_extract"
    
    xorriso -as mkisofs \
        -o "$OUTPUT_ISO" \
        -R -J -joliet-long \
        -V "GOSH_SLACK_${SLACK_VERSION}" \
        -b isolinux/isolinux.bin \
        -c isolinux/boot.cat \
        -no-emul-boot \
        -boot-load-size 4 \
        -boot-info-table \
        -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin \
        -eltorito-alt-boot \
        -e isolinux/efiboot.img \
        -no-emul-boot \
        -isohybrid-gpt-basdat \
        . 2>/dev/null || \
    xorriso -as mkisofs \
        -o "$OUTPUT_ISO" \
        -R -J -joliet-long \
        -V "GOSH_SLACK_${SLACK_VERSION}" \
        -b isolinux/isolinux.bin \
        -c isolinux/boot.cat \
        -no-emul-boot \
        -boot-load-size 4 \
        -boot-info-table \
        .
    
    log ""
    log "=== BUILD COMPLETE ==="
    log "Output: $OUTPUT_ISO"
    log "Size:   $(du -h "$OUTPUT_ISO" | cut -f1)"
    log ""
    log "Boot options:"
    log "  - 'Gosh Slack Auto-Install' - automated install, manual reboot"
    log "  - 'Gosh Slack Auto-Install (Custom)' - automated install + auto-reboot"
    log ""
    log "Kernel parameters for customization:"
    log "  gosh_hostname=NAME    Set hostname"
    log "  gosh_timezone=TZ      Set timezone (e.g., America/New_York)"
    log "  gosh_pass=PASSWORD    Set root password"
    log "  gosh_reboot=true      Auto-reboot after install"
}

main "$@"
